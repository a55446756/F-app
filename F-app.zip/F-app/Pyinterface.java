package com.example.quanttradingapp;

import com.chaquo.python.Python;
import com.chaquo.python.PyObject;

public class PythonInterface {
    private Python py;

    public PythonInterface() {
        py = Python.getInstance();
    }

    public String runScript(String scriptName) {
        PyObject pyObject = py.getModule(scriptName);
        return pyObject.callAttr("main").toString();
    }
}
