package com.example.quanttradingapp;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.List;

public class DataModel {
    private List<String> data;
    private ChatGPTApi chatGPTApi;

    public DataModel() {
        chatGPTApi = new ChatGPTApi();
        data = new ArrayList<>();
    }

    public void processPythonData(String scriptOutput) {
        try {
            JSONArray jsonArray = new JSONArray(scriptOutput);
            for (int i = 0; i < jsonArray.length(); i++) {
                String dataPoint = jsonArray.getString(i);
                data.add(dataPoint);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void processApiData() {
        JSONObject response = chatGPTApi.postData(getProcessedData());
        if (response != null) {
            try {
                JSONArray jsonArray = response.getJSONArray("processedData");
                data.clear();
                for (int i = 0; i < jsonArray.length(); i++) {
                    data.add(jsonArray.getString(i));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private String getProcessedData() {
        return new JSONArray(data).toString();
    }

    public List<String> getData() {
        return data;
    }
}
