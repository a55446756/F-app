package com.example.quanttradingapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main extends AppCompatActivity {
    private PythonInterface pythonInterface;
    private DataModel dataModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pythonInterface = new PythonInterface();
        dataModel = new DataModel();

        String scriptOutput = pythonInterface.runScript("script_name");
        dataModel.processPythonData(scriptOutput);

        dataModel.processApiData();

        TextView textView = findViewById(R.id.dataView);
        List<String> processedData = dataModel.getData();
        textView.setText(processedData.toString());
    }
}

